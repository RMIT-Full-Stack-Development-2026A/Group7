import SettingPage from './SettingPage';

export default function App() {
  return <SettingPage />;
}
