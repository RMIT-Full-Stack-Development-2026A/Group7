import React from 'react';

export default function LightTheme({ isActive, onToggle }) {
  // This component is conceptually separate but functionally tied to DarkTheme
  // In practice, it's the opposite state of DarkTheme
  return null; // The toggle is handled in DarkTheme component
}
