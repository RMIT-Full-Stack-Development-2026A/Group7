import React from 'react';
import Slider from '../../elements/Slider';

export default function SFX({ value, onChange, darkMode }) {
  return (
    <Slider
      label="Sound Effects"
      value={value}
      onChange={onChange}
      darkMode={darkMode}
    />
  );
}
