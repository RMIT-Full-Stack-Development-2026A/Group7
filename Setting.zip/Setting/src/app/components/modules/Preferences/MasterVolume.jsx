import React from 'react';
import Slider from '../../elements/Slider';

export default function MasterVolume({ value, onChange, darkMode }) {
  return (
    <Slider
      label="Master Volume"
      value={value}
      onChange={onChange}
      darkMode={darkMode}
    />
  );
}
