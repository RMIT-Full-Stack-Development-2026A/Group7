import React from 'react';

export default function CancelSetting({ onCancel }) {
  // This is handled in SaveSetting.jsx as part of the save/cancel panel
  return null;
}
