import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import SettingPage from './SettingPage.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <SettingPage />
  </StrictMode>,
)
