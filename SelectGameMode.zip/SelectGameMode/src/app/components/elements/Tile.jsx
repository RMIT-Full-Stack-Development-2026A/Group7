import React from 'react';

export default function Tile({ value, onClick }) {
  return (
    <button 
      className={`game-tile ${value ? 'filled' : ''}`}
      onClick={onClick}
    >
      {value && <span className={`tile-mark ${value === 'X' ? 'mark-x' : 'mark-o'}`}>{value}</span>}
    </button>
  );
}
