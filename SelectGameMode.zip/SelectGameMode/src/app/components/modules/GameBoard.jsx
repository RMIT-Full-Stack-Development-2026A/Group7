import React, { useState, useEffect } from 'react';
import Tile from '../elements/Tile';
import Timer from './Timer';
import PlayerDisplay from './PlayerDisplay';
import GiveUpModal from './GiveUp';

export default function GameBoard({ boardSize }) {
  const [board, setBoard] = useState([]);
  const [currentPlayer, setCurrentPlayer] = useState('X');
  const [timeLeft, setTimeLeft] = useState(60);
  const [showGiveUpModal, setShowGiveUpModal] = useState(false);
  const [lastMove, setLastMove] = useState(null);

  // Mock player data
  const players = {
    X: {
      name: 'Player 1',
      rank: 1523,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop'
    },
    O: {
      name: 'Player 2',
      rank: 1487,
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop'
    }
  };

  useEffect(() => {
    // Initialize empty board
    const newBoard = Array(boardSize).fill(null).map(() => Array(boardSize).fill(null));
    setBoard(newBoard);
  }, [boardSize]);

  const handleTimeUp = () => {
    setTimeLeft(prevTime => {
      if (prevTime <= 1) {
        // Skip turn when time runs out
        switchPlayer();
        return 60;
      }
      return prevTime - 1;
    });
  };

  const switchPlayer = () => {
    setCurrentPlayer(prev => prev === 'X' ? 'O' : 'X');
    setTimeLeft(60);
    setLastMove(null);
  };

  const handleTileClick = (row, col) => {
    // Check if tile is already occupied
    if (board[row][col]) {
      // Invalid move - skip turn
      alert('Invalid move! That tile is already occupied. Your turn is skipped.');
      switchPlayer();
      return;
    }

    // Make the move
    const newBoard = board.map(r => [...r]);
    newBoard[row][col] = currentPlayer;
    setBoard(newBoard);
    setLastMove({ row, col });
    
    // Switch to next player
    switchPlayer();
  };

  const handleCancelMove = () => {
    // Skip current player's turn
    switchPlayer();
  };

  const handleGiveUp = () => {
    setShowGiveUpModal(true);
  };

  const confirmGiveUp = () => {
    alert(`${players[currentPlayer].name} has given up!`);
    setShowGiveUpModal(false);
  };

  const cancelGiveUp = () => {
    setShowGiveUpModal(false);
  };

  return (
    <div className="game-container">
      {showGiveUpModal && (
        <GiveUpModal onConfirm={confirmGiveUp} onCancel={cancelGiveUp} />
      )}
      
      <div className="game-layout">
        {/* Left Panel */}
        <div className="left-panel">
          <div className="panel-content">
            <Timer seconds={timeLeft} onTimeUp={handleTimeUp} isActive={true} />
            
            <div className="control-buttons">
              <button 
                className="btn btn-danger w-100 mb-3 give-up-btn"
                onClick={handleGiveUp}
              >
                <i className="bi bi-flag-fill me-2"></i>
                Give Up
              </button>
              
              <button 
                className="btn btn-warning w-100 cancel-move-btn"
                onClick={handleCancelMove}
              >
                <i className="bi bi-arrow-counterclockwise me-2"></i>
                Cancel Move
              </button>
            </div>
          </div>
        </div>

        {/* Center - Game Board */}
        <div className="center-panel">
          <div className="turn-indicator">
            <h3>
              {currentPlayer === 'X' ? 'P1 (X)' : 'P2 (O)'}'s Turn
            </h3>
          </div>
          
          <div className="board-container">
            <div 
              className="game-board"
              style={{
                gridTemplateColumns: `repeat(${boardSize}, 1fr)`,
                gridTemplateRows: `repeat(${boardSize}, 1fr)`
              }}
            >
              {board.map((row, rowIndex) => (
                row.map((cell, colIndex) => (
                  <Tile
                    key={`${rowIndex}-${colIndex}`}
                    value={cell}
                    onClick={() => handleTileClick(rowIndex, colIndex)}
                  />
                ))
              ))}
            </div>
          </div>
        </div>

        {/* Right Panel - Player Displays */}
        <div className="right-panel">
          <div className="players-section">
            <div className="mb-4">
              <h6 className="text-muted mb-3">OPPONENT</h6>
              <PlayerDisplay 
                player={players[currentPlayer === 'X' ? 'O' : 'X']} 
                isOpponent={true}
              />
            </div>
            
            <div>
              <h6 className="text-muted mb-3">YOU</h6>
              <PlayerDisplay 
                player={players[currentPlayer]} 
                isOpponent={false}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}