import React from 'react';

export default function BoardSizeSelector({ onSelectSize }) {
  return (
    <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Choose Board Size</h5>
          </div>
          <div className="modal-body text-center">
            <p className="mb-4">Select the size of your Tic-Tac-Toe board</p>
            <div className="d-flex gap-3 justify-content-center">
              <button 
                className="btn btn-primary btn-lg px-5"
                onClick={() => onSelectSize(15)}
              >
                15 x 15
              </button>
              <button 
                className="btn btn-primary btn-lg px-5"
                onClick={() => onSelectSize(30)}
              >
                30 x 30
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
