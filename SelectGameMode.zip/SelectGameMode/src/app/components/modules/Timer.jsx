import React, { useEffect } from 'react';

export default function Timer({ seconds, onTimeUp, isActive }) {
  useEffect(() => {
    if (!isActive || seconds <= 0) return;

    const timer = setTimeout(() => {
      onTimeUp();
    }, 1000);

    return () => clearTimeout(timer);
  }, [seconds, onTimeUp, isActive]);

  const getTimerClass = () => {
    if (seconds <= 10) return 'timer-critical';
    if (seconds <= 20) return 'timer-warning';
    return 'timer-normal';
  };

  return (
    <div className={`timer-display ${getTimerClass()}`}>
      <i className="bi bi-clock"></i>
      <div className="timer-value">{seconds}s</div>
    </div>
  );
}
