import React, { useState, useEffect } from 'react';
import BoardSizeSelector from './app/components/modules/BoardSizeSelector';
import BoardLoadAnimation from './app/components/modules/BoardLoadAnimation';
import CountdownModal from './app/components/modules/CountDown';
import GameBoard from './app/components/modules/GameBoard';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './GameBoard.css';

export default function App() {
  const [gameState, setGameState] = useState('SELECT_SIZE'); // SELECT_SIZE, LOADING, COUNTDOWN, PLAYING
  const [boardSize, setBoardSize] = useState(null);

  const handleSelectSize = (size) => {
    setBoardSize(size);
    setGameState('LOADING');
    
    // Simulate board rendering time (2-3 seconds)
    setTimeout(() => {
      setGameState('COUNTDOWN');
    }, 2500);
  };

  const handleCountdownComplete = () => {
    setGameState('PLAYING');
  };

  return (
    <div style={{ minHeight: '100vh' }}>
      {gameState === 'SELECT_SIZE' && (
        <BoardSizeSelector onSelectSize={handleSelectSize} />
      )}
      
      {gameState === 'LOADING' && (
        <BoardLoadAnimation />
      )}
      
      {gameState === 'COUNTDOWN' && (
        <CountdownModal onComplete={handleCountdownComplete} />
      )}
      
      {gameState === 'PLAYING' && boardSize && (
        <GameBoard boardSize={boardSize} />
      )}
    </div>
  );
}
